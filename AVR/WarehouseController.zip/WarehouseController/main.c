/*
 * WarehouseController.c
 *
 * Created: 2019-06-11 오후 4:56:47
 * Author : tjoeun
 */ 

#include <avr/io.h>
#include <util/delay.h>
#define F_CPU 16000000UL
#include <avr/interrupt.h>
#include <stdlib.h>
#include <string.h>

#include "ADC.h"
#include "FND4digit.h"
#include "Keypad.h"
#include "Timer.h"
#include "Uart.h"

#define ROOM1_DESIRE_UP '1'
#define ROOM1_DESIRE_DOWN '2'
#define ROOM2_DESIRE_UP '3'
#define ROOM2_DESIRE_DOWN '4'
#define ROOM3_DESIRE_UP '5'
#define ROOM3_DESIRE_DOWN '6'

#define ROOM1_LED PORTD3
#define ROOM2_LED PORTB4
#define ROOM3_LED PORTB5

#define SELECTED_ROOM1 1
#define SELECTED_ROOM2 2
#define SELECTED_ROOM3 3

void StorageController_Init(void);

extern volatile char time_flag;
extern volatile char RX_flag, RX_data, RX_cmd_count;
extern char buffer[COMMAND_MAX][BUFFER_MAX];
extern char FND[4];

char selected_room;
signed char room1_desire = 20, room2_desire = 20, room3_desire = 20, room1_current, room2_current, room3_current;

char long_key_flag;

int main(void)
{
	char cmd_idx = 0;
	char *command;
   StorageController_Init();
    while (1) 
    {
		
		CompareTemper();
		if(time_flag) {
			room1_current = Volt_to_temperature(ADC_converting_value(2));
			if(room1_current <= -30) room1_current = -30;
			else if(room1_current >= 30) room1_current = 30;
			
			room2_current = Volt_to_temperature(ADC_converting_value(1));
			if(room2_current <= -30) room2_current = -30;
			else if(room2_current >=  30) room2_current = 30;
			
			room3_current = Volt_to_temperature(ADC_converting_value(0));
			if(room3_current <= -30) room3_current = -30;
			else if(room3_current >=  30) room3_current = 30;
			
			printf("room1_current : %d\n", room1_current);
			_delay_us(10);
			printf("room2_current : %d\n", room2_current);
			_delay_us(10);
			printf("room3_current : %d\n", room3_current);
			
			
			time_flag = 0;
		}
		
		if(RX_cmd_count) {
			RX_cmd_count--;
			command = strtok(buffer[cmd_idx], " : ");
			if(!strcmp(command, "room1_desire")) { //strcmp() : 비교해서 같으면 return 0
				room1_desire = atoi(strtok(NULL, " : "));
				if(room1_desire <= -30) room1_desire = -30;
				else if(room1_desire >=  30) room1_desire = 30;
				printFND_temper(room1_desire);
				printf("room1_desire : %d\n", room1_desire);
			}
			else if(!strcmp(command, "room2_desire")) { 
				room2_desire = atoi(strtok(NULL, " : "));
				if(room2_desire <= -30) room2_desire = -30;
				else if(room2_desire >=  30) room2_desire = 30;
				printFND_temper(room2_desire);
				printf("room2_desire : %d\n", room2_desire);
			}
			else if(!strcmp(command, "room3_desire")) {
				room3_desire = atoi(strtok(NULL, " : "));
				if(room3_desire <= -30) room3_desire = -30;
				else if(room3_desire >=  30) room3_desire = 30;
				printFND_temper(room3_desire);
				printf("room3_desire : %d\n", room3_desire);
			}
			cmd_idx++;
			cmd_idx = cmd_idx % COMMAND_MAX;
		}
		
		if(long_key_flag) {
			if(Keyscan() != 'A')
			{
				_delay_us(200);
				if (Keyscan() != 'A')
				{
					switch(Keyscan()) {
						case 'B' : FND_update_value(1); break;
						case 'C' : FND_update_value(2); break;
						case 'D' :  FND_update_value(3); break;
						case 'E' :  FND_update_value(4); break;
						case 'F' : FND_update_value(5); break;
						case 'G': FND_update_value(6); break;
						case 'H': FND_update_value(7); break;
						case 'I': FND_update_value(8); break;
						case 'J': FND_update_value(9); break;
						case 'K': FND_update_value(10); break;
						case 'L': FND_update_value(11); break;
						case 'M': FND_update_value(12); break;
						case 'N': FND_update_value(13); break;
						case 'O': FND_update_value(14); break;
						case 'P': FND_update_value(15); break;
						case 'Q': FND_update_value(16); break;
						
						/*
						case 'B': printFND_temper(room1_desire); break; //STROAGE1
						case 'C': room1_desire += 1; 
								  if(room1_desire >= 30) room1_desire = 30;
								  printFND_temper(room1_desire); break;
						case 'D': room1_desire--; 
								  if(room1_desire <= -30) room1_desire = -30;
								  printFND_temper(room1_desire); break;
					
						case 'F': printFND_temper(2000+room2_desire); break; //STROAGE2
						case 'G': room2_desire++; 
								  if(room2_desire >= 30) room2_desire = 30;
								  printFND_temper(2000+room2_desire); break;
						case 'H': room2_desire--; 
								  if(room2_desire <= -30) room2_desire = -30;
								  printFND_temper(2000+room2_desire); break;
					
						case 'J': printFND_temper(3000+room3_desire); break; //STROAGE3
						case 'K': room3_desire++; 
								  if(room3_desire >= 30) room3_desire = 30;
								  printFND_temper(3000+room3_desire); break;
						case 'L': room3_desire--; 
								  if(room3_desire <= -30) room3_desire = -30;
								  printFND_temper(3000+room3_desire); break;
						*/
					}
				
					long_key_flag = 0;
				}
			
			}
		}
		else
		{
			if(Keyscan() == 'A')
			{
				long_key_flag = 1;
			}
		}
		_delay_ms(10);
    }
}

void StorageController_Init(void) {
	
	Timer0_init();
	FND4digit_init_shiftR();
	
	Keypad_init();
	ADC_init();
	UART0_init(9600);
	
	DDRD |= 1 << ROOM1_LED; //LED RED
	PORTD &= ~(1 << ROOM1_LED);
	DDRB |= 1 << ROOM3_LED | 1 << ROOM2_LED; //LED BLUE , LED org
	PORTB &= ~(1 << ROOM3_LED | 1 << ROOM2_LED);
	
	
	sei();
	
	return;
}

void printFND_temper(int temp) {
	
	
	if(temp >= 0) {
		FND_update_value(temp);
		FND[2] = 255;
		//FND[3] = FND4digit_font[COOLING];
	}
	else{
		//temp = temp * -1; //양수 값으로 변경
		FND_update_value(temp * -1);
		FND[2] = ~(1 << FND_g);
		//FND[3] = FND4digit_font[COOLING];
	}
	
	return;
}

void CompareTemper(){
	
	if(room1_current > room1_desire) //RED
		PORTB |= 1 << ROOM1_LED;
	else
		PORTB &= ~(1 << ROOM1_LED);
	
	if(room2_current > room2_desire) //orange
		PORTB |= 1 << ROOM2_LED;
	else 
		PORTB &= ~(1 << ROOM2_LED);
		
	if(room3_current > room3_desire) //BLUE
		PORTD |= 1 << ROOM3_LED;
	else
		PORTD &= ~(1 << ROOM3_LED);
		
	return;
}