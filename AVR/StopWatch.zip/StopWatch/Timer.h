﻿/*
 * Timer.h
 *
 * Created: 2019-04-15 오후 3:36:06
 *  Author: user
 */ 


#ifndef TIMER_H_
#define TIMER_H_

void Timer0_init(void);

#endif /* TIMER_H_ */