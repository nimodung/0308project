﻿/*
 * External_INT.h
 *
 * Created: 2019-04-22 오후 3:33:31
 *  Author: user
 */ 


#ifndef EXTERNAL_INT_H_
#define EXTERNAL_INT_H_


void EINT_init_for_HC_SR04(void);


#endif /* EXTERNAL_INT_H_ */