/*
 * Clock.c
 *
 * Created: 2019-05-01 오후 1:40:18
 * Author : Kim Hee Ram
 */ 

#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>
#include <avr/interrupt.h>

#include "FND4digit.h"
#include "Keypad.h"
#include "Timer.h"
#include "Speaker.h"

#define CLOCK_MODE 0
#define COOK_TIMER_MODE 1
#define STOP_WATCH_MODE 2

void cook_timer_process(char key_value);
void clock_process(char key_value);
void stop_watch_process(char key_value);

extern volatile char start_flag, w_flag, clear_flag, time_flag,countdown_flag, speakout_flag, stop_start_flag;
extern volatile char i, sec, min, cook_sec, cook_min, stop_sec, stop_msec;
extern int san_rabit_bell_tune[], san_rabit_bell_beat[];

char mode; 

int main(void)
{
	char long_key_flag = 0;
    Timer0_init();
	Timer1_init_CTC_outA(); 
	clock_Keypad_init();
	FND4digit_init_shiftR();
	sei();
	
    while (1) 
    {
		if(speakout_flag) 
		{
			speakout_flag = 0;
			//Music_player(san_rabit_bell_tune, san_rabit_bell_beat);
			if(mode == COOK_TIMER_MODE) beep(3);
			else if(mode == STOP_WATCH_MODE) beep(1);
		}
		if(time_flag) 
		{
			FND_update_time(stop_msec, stop_sec);
			time_flag = 0;
		}
		
		if(long_key_flag) 
		{
			if(Keyscan_sub() != 0) 
			{
				
				if(mode == CLOCK_MODE) clock_process(Keyscan_sub());
				else if(mode == COOK_TIMER_MODE) cook_timer_process(Keyscan_sub()); 
				else if(mode == STOP_WATCH_MODE) stop_watch_process(Keyscan_sub());
				long_key_flag = 0;
				
			}
		}
		else 
		{
			if(Keyscan_sub() == 0) 
			{
				long_key_flag = 1;
			}
		
		}
    }
}

void cook_timer_process(char key_value)
{
	switch(key_value)
	{
		case 1 :
			countdown_flag = 0;
			mode = STOP_WATCH_MODE;
			FND_update_time(stop_msec, stop_sec);
			break;
		case 2 :
			cook_sec++;
			if(cook_sec >= 60) cook_sec = 0;
			FND_clock(cook_sec, cook_min);
			break;
		case 3 :
			cook_min++;
			if(cook_min >= 60) cook_min = 0;
			FND_clock(cook_sec, cook_min);
			break;
		case 4 : 
			countdown_flag = 1;
			break;
		default: break;
	}
	return;
}

void clock_process(char key_value)
{
	if(key_value == 1)
	{
		mode = COOK_TIMER_MODE;
		FND_clock(cook_sec, cook_min);
	}
	return;
}

void stop_watch_process(char key_value) {
	switch(key_value)
	{
		case 1 :
			stop_start_flag = 0;
			clear_flag = 1;
			mode = CLOCK_MODE;
			FND_clock(sec, min);
			break;
		case 2 : //clear
			clear_flag = 1;
			stop_start_flag = 0;
			w_flag = 0;
			break;
		case 3 : //lap
			stop_start_flag = 1;
			if(w_flag == 0)w_flag = 1;
			else w_flag = 0;
			break;
		case 4 :
			stop_start_flag = 1;
			w_flag = 1;
			speakout_flag = 1;
			break;
		default: break;
	}
	return;
}
