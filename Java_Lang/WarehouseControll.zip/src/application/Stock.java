package application;

public class Stock {

	String state;
	String productName;
	int stockAmount;
	RootController controller = new RootController();
	
	Stock(String productName, int stockAmount, String state){
		this.productName = productName;
		this.stockAmount = stockAmount;
		this.state = state;
	}
	
	
}
