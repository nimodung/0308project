package application;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

import gnu.io.CommPort;
import gnu.io.CommPortIdentifier;
import gnu.io.SerialPort;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;


public class RootController implements Initializable {

	@FXML
	private Button btn_room1_in, btn_room1_out, btn_room2_in, 
					btn_room2_out, btn_room3_in, btn_room3_out,
					btn_room1_modify;

	@FXML
	private Label lb_room1_desire, lb_room2_desire, lb_room3_desire, 
					lb_room1_current, lb_room2_current, lb_room3_current,
					lb_room1_product_name, lb_room2_product_name, lb_room3_product_name,
					lb_room1_product_amount, lb_room2_product_amount, lb_room3_product_amount;
	@FXML
	private Slider sld_room1, sld_room2, sld_room3;

	@FXML private TextField tf_room1_in, tf_room2_in, tf_room3_in,
							tf_room1_out, tf_room2_out, tf_room3_out;
	
	static InputStream in;
	static OutputStream out;
	static SerialPort serialPort;

	
	static Label lbRoom1DesireTemp, lbRoom2DesireTemp, lbRoom3DesireTemp,
				lbRoom1CurrentTemp, lbRoom2CurrentTemp, lbRoom3CurrentTemp; //inner class���� ��ü ����ϱ� ����
	
	Stock room1, room2, room3;
	
	private Connection conn = null;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		lbRoom1DesireTemp = lb_room1_desire;
		lbRoom2DesireTemp = lb_room2_desire;
		lbRoom3DesireTemp = lb_room3_desire;
		lbRoom1CurrentTemp = lb_room1_current;
		lbRoom2CurrentTemp = lb_room2_current;
		lbRoom3CurrentTemp = lb_room3_current;
		
		
		try {
			new RootController().DBconnect("root", "1234");
			new RootController().connect("COM7");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		room1 = new Stock("���", 100, "room1");
		room2 = new Stock("�ݶ�", 200, "room2");
		room3 = new Stock("����ũ����", 50, "room3");
		
		lb_room1_product_name.setText(room1.productName);
		lb_room1_product_amount.setText(Integer.toString(room1.stockAmount));
		lb_room2_product_name.setText(room2.productName);
		lb_room2_product_amount.setText(Integer.toString(room2.stockAmount));
		lb_room3_product_name.setText(room3.productName);
		lb_room3_product_amount.setText(Integer.toString(room3.stockAmount));
		
		sld_room1.valueProperty().addListener(new ChangeListener<Number>() {

			@Override
			public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
				int value = newValue.intValue();
				String strValue = value + "\n";
				try {
					out.write(("room1_desire : "+strValue).getBytes());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
	
		sld_room2.valueProperty().addListener(new ChangeListener<Number>() {

			@Override
			public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
				int value = newValue.intValue();
				String strValue = value + "\n";
				try {
					out.write(("room2_desire : "+strValue).getBytes());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		
		sld_room3.valueProperty().addListener(new ChangeListener<Number>() {

			@Override
			public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
				int value = newValue.intValue();
				String strValue = value + "\n";
				try {
					out.write(("room3_desire : "+strValue).getBytes());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		
		
		btn_room1_in.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				
				StockManagementProcess(event);
			}
		});
		btn_room1_out.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				
				StockManagementProcess(event);
			}
		});
		btn_room2_in.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				
				StockManagementProcess(event);
			}
		});
		btn_room2_out.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				
				StockManagementProcess(event);
			}
		});
		btn_room3_in.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				
				StockManagementProcess(event);
			}
		});
		btn_room3_out.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				
				StockManagementProcess(event);
			}
		});
		
		btn_room1_modify.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				String query = "SELECT stockname, stockamount from warehousedb.stock where stockname = '�ݶ�';";
				
				
			}
		});
	}
	
	void StockManagementProcess(ActionEvent event) {
		
		String btnInOutID = ((Button)event.getSource()).getId();
		
		if(btnInOutID.equals("btn_room1_in")) {
			room1.stockAmount += Integer.parseInt(tf_room1_in.getText());
			lb_room1_product_amount.setText(Integer.toString(room1.stockAmount));
			tf_room1_in.clear();
		}
		else if(btnInOutID.equals("btn_room1_out")) {
			room1.stockAmount -= Integer.parseInt(tf_room1_out.getText());
			lb_room1_product_amount.setText(Integer.toString(room1.stockAmount));
			tf_room1_out.clear();
		}
		else if(btnInOutID.equals("btn_room2_in")) {
			room2.stockAmount += Integer.parseInt(tf_room2_in.getText());
			lb_room2_product_amount.setText(Integer.toString(room2.stockAmount));
			tf_room2_in.clear();
		}
		else if(btnInOutID.equals("btn_room2_out")) {
			room2.stockAmount -= Integer.parseInt(tf_room2_out.getText());
			lb_room2_product_amount.setText(Integer.toString(room2.stockAmount));
			tf_room2_out.clear();
		}
		else if(btnInOutID.equals("btn_room3_in")) {
			room3.stockAmount += Integer.parseInt(tf_room3_in.getText());
			lb_room3_product_amount.setText(Integer.toString(room3.stockAmount));
			tf_room3_in.clear();
		}
		else if(btnInOutID.equals("btn_room3_out")) {
			room3.stockAmount -= Integer.parseInt(tf_room3_out.getText());
			lb_room3_product_amount.setText(Integer.toString(room3.stockAmount));
			tf_room3_out.clear();
		}
	}

	// �ø��� ������ �ϱ����� �Լ�
	private void connect(String portName) throws Exception {

		System.out.printf("Port : %s\n", portName);

		CommPortIdentifier portIdentifier = CommPortIdentifier.getPortIdentifier(portName);

		if (portIdentifier.isCurrentlyOwned()) { // currentlyowned : ���� �����ֳ�
			System.out.println("Error: Port is currently in use");
		} else {
			CommPort commPort = portIdentifier.open(this.getClass().getName(), 2000);

			if (commPort instanceof SerialPort) {
				serialPort = (SerialPort) commPort;
				serialPort.setSerialPortParams( // �ø��� ��Ʈ ����
						9600, // ��� �ӵ�
						SerialPort.DATABITS_8, // ���Ʈ ����ΰ�,
						SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);

				in = serialPort.getInputStream();

				out = serialPort.getOutputStream();

				(new Thread(new SerialReader(in, new RootController()))).start();
				(new Thread(new SerialWriter(out))).start();
			}
		}
	}

	public static class SerialReader implements Runnable {
		InputStream in;
		RootController root;
		
		
		public SerialReader(InputStream in, RootController root) {
			this.in = in;
			this.root = root;
		}

		@Override
		public void run() {

			byte[] buffer = new byte[1024];
			int len = -1;
			String str = "";
			
			try {
				while ((len = this.in.read(buffer)) > -1) {
					 
					
					if(len > 0) { 
						str += new String(buffer, 0, len);
						
						if(str.charAt(str.length()-1) == '\n') {
							String[] strArr = str.split(" : |\n");
							System.out.println(strArr[0] + " : " + strArr[1]);
							str = "";
						  
							if(strArr[0].equals("room1_desire")) { 
								Platform.runLater(new Runnable() {
						  
									@Override public void run() { 
										lbRoom1DesireTemp.setText(strArr[1]); 
									} 
							
								}); 
							}	
							else if(strArr[0].equals("room2_desire")) { 
								Platform.runLater(new Runnable() {
									@Override public void run() { 
										lbRoom2DesireTemp.setText(strArr[1]); 
									} 
								}); 
							}
							else if(strArr[0].equals("room3_desire")) { 
								Platform.runLater(new Runnable() {
									@Override public void run() { 
										lbRoom3DesireTemp.setText(strArr[1]); 
									} 
								}); 
							}
							else if(strArr[0].equals("room1_current")) { 
								Platform.runLater(new Runnable() {
									@Override public void run() { 
										lbRoom1CurrentTemp.setText(strArr[1]); 
									} 
								}); 
							}
							else if(strArr[0].equals("room2_current")) { 
								Platform.runLater(new Runnable() {
									@Override public void run() { 
										lbRoom2CurrentTemp.setText(strArr[1]); 
									} 
								}); 
							}
							else if(strArr[0].equals("room3_current")) { 
								Platform.runLater(new Runnable() {
									@Override public void run() { 
										lbRoom3CurrentTemp.setText(strArr[1]); 
									} 
								}); 
							}
							
						} 
						
					}
						
				}
			} catch (IOException e) {

				e.printStackTrace();
			}

		}
	}

	public static class SerialWriter implements Runnable {
		OutputStream out;

		public SerialWriter(OutputStream out) {
			this.out = out;
		}

		@Override
		public void run() {
			try {
				int c = 0;
				System.out.println("\n Keyboard Input Read!!!");// �ȳ� ���� ���
				while ((c = System.in.read()) > -1) {
					this.out.write(c);
				}
			} catch (IOException e) {

				e.printStackTrace();
			}
		}
	}
	
	private void DBconnect(String user, String pw) throws Exception{
		
		try {
		String url
			= "jdbc:mysql://localhost:3306?characterEncoding=UTF-8&serverTimezone=UTC&useSSL=false";
		
			conn = DriverManager.getConnection(url, user, pw);
			System.out.println(conn.toString());
		} catch (SQLException e) {
			System.out.println("SQLException : " + e.getMessage());
			System.out.println("SQLState : " + e.getSQLState());
			System.out.println("VendorError : " + e.getErrorCode());
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
	
}
