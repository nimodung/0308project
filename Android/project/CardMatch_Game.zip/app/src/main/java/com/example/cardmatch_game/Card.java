package com.example.cardmatch_game;

public class Card { //c언어의 구조체 역할
    //처음 시작해서
    public static final int CARD_SHOW = 1;
    public static final int CARD_CLOSE = 2;

    //사용자가 터치해서 카드 오픈
    public static final int CARD_PLAYER_OPEN = 3;

    //MATCH 상태
    public static final int CARD_MATCH = 4;

    public static final int IMG_RED = 1;
    public static final int IMG_BLUE = 2;
    public static final int IMG_BLACK = 3;

    public static final int IMG_LEVEL1_1 = 4;
    public static final int IMG_LEVEL1_2 = 5;
    public static final int IMG_LEVEL1_3 = 6;
    public static final int IMG_LEVEL1_4 = 7;
    public static final int IMG_LEVEL1_5 = 8;
    public static final int IMG_LEVEL1_6 = 9;
    public static final int IMG_LEVEL1_7 = 10;
    public static final int IMG_LEVEL1_8 = 11;

    public static final int IMG_LEVEL2_1 = 12;
    public static final int IMG_LEVEL2_2 = 13;
    public static final int IMG_LEVEL2_3 = 14;
    public static final int IMG_LEVEL2_4 = 15;
    public static final int IMG_LEVEL2_5 = 16;
    public static final int IMG_LEVEL2_6 = 17;
    public static final int IMG_LEVEL2_7 = 18;
    public static final int IMG_LEVEL2_8 = 19;

    int m_State; //앞 뒷면의 상태
    int m_Image; //카드 종류

   Card(int _Image){ //생성자 //return 값이 없어야함
       m_State =  CARD_SHOW;//처음 시작에 카드 앞면 보여주기
       m_Image = _Image;
    }
}
